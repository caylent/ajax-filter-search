<?php 
// Silence is golden
?>
